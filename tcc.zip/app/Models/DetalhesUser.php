<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetalhesUser extends Model
{
    protected $table = 'detalhes_user';
    use HasFactory;
}
