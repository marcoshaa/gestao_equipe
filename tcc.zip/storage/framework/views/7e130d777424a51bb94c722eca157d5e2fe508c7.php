
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('/css/geral.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/loading.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .card_element{
            background:#ffffff8a;
        }
        .element_content{
            justify-content: space-between;
        }
        .text_apresentacao{
            color:white;
            font-size:20px;
        }
        .espaco_elemento {
            margin: 20px;
            padding: 5px 30px;
            background: #393B3C;
            border-radius: 5px;
        }
        .text_titulo{
            color:#ae0233;
            font-size:20px;
            font-weight: bolder;
        }
        .grade_pdf{
            display:grid;
        }
        .grade_pdf {
            margin: 20px;
            display: grid;
            grid-template-columns: auto auto auto auto auto;
            grid-template-rows: 150px 150px 150px;
            gap: 90px 120px;
        }
        .bi-filetype-pdf {
            font-size: 50px;
            color: #ae0233;
        }
        .icone_pdf{
            margin-bottom: 10px;
        }
        .elemento_card{
            background: #393b3c;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0px 0px 8px #ae0233;
            text-decoration-line: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page_content">
        <div class="all_elements">
            <div class="topo_content">
                <div class="espaco_elemento">
                    <p class="text_titulo">storage/<?php echo e($link); ?></p>
                </div>
                <div class="grade_pdf">
                    <?php $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="elemento_card" href="<?php echo e($pdf->link); ?>">
                            <div class="icone_pdf">
                                <i class="bi bi-filetype-pdf"></i>
                            </div>
                            <div>
                                <p class="text_titulo"><?php echo e($pdf->titulo); ?></p>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao\resources\views/site/materialPorMateria.blade.php ENDPATH**/ ?>