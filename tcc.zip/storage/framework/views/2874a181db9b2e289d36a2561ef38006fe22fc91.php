
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('/css/geral.css')); ?>" rel="stylesheet">
<style>
    .group_element>table{
        color:white;
        width: 100%;
        margin-top:5%;
    }

    table, th, td {
        border: 1px solid;
    }
    tr>td{
        padding: 4px 3px;
        width: auto;
    }
    .idUserTable{
        text-align: -webkit-center;
        width: 15%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page_content">
        <div class="all_elements">
            <div class="topo_content">
                <div class="group_element">
                    <table>
                        <thead>
                            <tr>
                                <td>Título</td>
                                <td class="idUserTable">Id User</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->titulo); ?></td>
                                    <td class="idUserTable"><?php echo e($log->id_user); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao\resources\views/adm/log.blade.php ENDPATH**/ ?>