
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('/css/geral.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/loading.css')); ?>">
    <style>
        .card_element{
            background:#ffffff8a;
        }
        .element_content{
            justify-content: space-between;
        }
        .text_apresentacao{
            color:white;
            font-size:20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page_content">
        <div class="all_elements">
            <div class="topo_content">
                <div class="elemento_50_alt">
                    <div class="espaco_elemento">    
                        <div class="flex_card_element">
                            <div class="card_element">
                                <a class="element_content" href="<?php echo e(route('viewMaterialSelec','matematica')); ?>">
                                    <i class="bi bi-folder icon_sf"></i>
                                    <p class="title_card">Matemática</p>
                                </a>
                            </div>
                            <div class="card_element">
                                <a class="element_content" href="<?php echo e(route('viewMaterialSelec','logica')); ?>">
                                    <i class="bi bi-folder icon_sf"></i>
                                    <p class="title_card">Lógica</p>
                                </a>
                            </div>
                            <div class="card_element">
                                <a class="element_content" href="<?php echo e(route('viewMaterialSelec','algoritmo')); ?>">
                                    <i class="bi bi-folder icon_sf"></i>
                                    <p class="title_card">Algoritmo</p>
                                </a>
                            </div>
                            <div class="card_element">
                                <a class="element_content" href="<?php echo e(route('viewMaterialSelec','estruturaderepeticao')); ?>">
                                    <i class="bi bi-folder icon_sf"></i>
                                    <p class="title_card">Estrutura de<br>repetição</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>                 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao\resources\views/site/material.blade.php ENDPATH**/ ?>